'use client'

import { useState, useEffect } from 'react'
import { ShoppingCart, Search, Menu, X, Heart, User, Plus, Minus, Trash2, ArrowRight, Truck, Shield } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Badge } from '@/components/ui/badge'
import { Card, CardContent } from '@/components/ui/card'
import { Sheet, SheetContent, SheetTrigger } from '@/components/ui/sheet'
import { Separator } from '@/components/ui/separator'

interface CartItem {
  id: number
  name: string
  price: number
  originalPrice: number
  image: string
  size: string
  color: string
  quantity: number
  stock: number
}

export default function CartPage() {
  const [isScrolled, setIsScrolled] = useState(false)
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false)
  const [cartItems, setCartItems] = useState<CartItem[]>([
    {
      id: 1,
      name: "Premium Cotton T-Shirt",
      price: 49.99,
      originalPrice: 79.99,
      image: "https://images.unsplash.com/photo-1521572163474-6864f9cf17ab?w=200&h=200&fit=crop",
      size: "M",
      color: "White",
      quantity: 2,
      stock: 15
    },
    {
      id: 2,
      name: "Slim Fit Denim Jeans",
      price: 89.99,
      originalPrice: 129.99,
      image: "https://images.unsplash.com/photo-1542272604-787c3835535d?w=200&h=200&fit=crop",
      size: "32",
      color: "Blue",
      quantity: 1,
      stock: 8
    },
    {
      id: 3,
      name: "Classic Leather Jacket",
      price: 199.99,
      originalPrice: 299.99,
      image: "https://images.unsplash.com/photo-1551488831-00ddcb6c6bd3?w=200&h=200&fit=crop",
      size: "L",
      color: "Black",
      quantity: 1,
      stock: 5
    }
  ])
  const [promoCode, setPromoCode] = useState('')
  const [discount, setDiscount] = useState(0)

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 20)
    }
    window.addEventListener('scroll', handleScroll)
    return () => window.removeEventListener('scroll', handleScroll)
  }, [])

  const updateQuantity = (id: number, newQuantity: number) => {
    if (newQuantity < 1) return
    
    setCartItems(prev => prev.map(item => {
      if (item.id === id) {
        return { ...item, quantity: Math.min(newQuantity, item.stock) }
      }
      return item
    }))
  }

  const removeItem = (id: number) => {
    setCartItems(prev => prev.filter(item => item.id !== id))
  }

  const subtotal = cartItems.reduce((sum, item) => sum + (item.price * item.quantity), 0)
  const shipping = subtotal > 100 ? 0 : 9.99
  const total = subtotal + shipping - discount

  const applyPromoCode = () => {
    if (promoCode.toUpperCase() === 'SAVE20') {
      setDiscount(subtotal * 0.2)
    } else if (promoCode.toUpperCase() === 'SAVE10') {
      setDiscount(subtotal * 0.1)
    } else {
      alert('Invalid promo code')
      setDiscount(0)
    }
  }

  const cartItemCount = cartItems.reduce((sum, item) => sum + item.quantity, 0)

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Navigation */}
      <nav className={`fixed top-0 w-full z-50 transition-all duration-300 ${isScrolled ? 'bg-white shadow-lg' : 'bg-white/95 backdrop-blur-sm'}`}>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center">
              <h1 className="text-2xl font-bold bg-gradient-to-r from-purple-600 to-pink-600 bg-clip-text text-transparent">
                MIXARO
              </h1>
            </div>

            <div className="hidden md:flex items-center space-x-8">
              <a href="/" className="text-gray-700 hover:text-purple-600 transition-colors font-medium">Home</a>
              <a href="/shop" className="text-gray-700 hover:text-purple-600 transition-colors font-medium">Shop</a>
              <a href="#" className="text-gray-700 hover:text-purple-600 transition-colors font-medium">Collections</a>
              <a href="#" className="text-gray-700 hover:text-purple-600 transition-colors font-medium">About</a>
              <a href="#" className="text-gray-700 hover:text-purple-600 transition-colors font-medium">Contact</a>
            </div>

            <div className="flex items-center space-x-4">
              <Button variant="ghost" size="icon" className="relative">
                <Search className="h-5 w-5" />
              </Button>
              <Button variant="ghost" size="icon" className="relative">
                <Heart className="h-5 w-5" />
              </Button>
              <Button variant="ghost" size="icon" className="relative">
                <ShoppingCart className="h-5 w-5" />
                {cartItemCount > 0 && (
                  <Badge className="absolute -top-2 -right-2 h-5 w-5 rounded-full p-0 text-xs">
                    {cartItemCount}
                  </Badge>
                )}
              </Button>
              <Button variant="ghost" size="icon">
                <User className="h-5 w-5" />
              </Button>

              <Sheet open={mobileMenuOpen} onOpenChange={setMobileMenuOpen}>
                <SheetTrigger asChild className="md:hidden">
                  <Button variant="ghost" size="icon">
                    <Menu className="h-5 w-5" />
                  </Button>
                </SheetTrigger>
                <SheetContent side="right" className="w-80">
                  <div className="flex flex-col space-y-4 mt-8">
                    <a href="/" className="text-lg font-medium text-gray-700 hover:text-purple-600 transition-colors">Home</a>
                    <a href="/shop" className="text-lg font-medium text-gray-700 hover:text-purple-600 transition-colors">Shop</a>
                    <a href="#" className="text-lg font-medium text-gray-700 hover:text-purple-600 transition-colors">Collections</a>
                    <a href="#" className="text-lg font-medium text-gray-700 hover:text-purple-600 transition-colors">About</a>
                    <a href="#" className="text-lg font-medium text-gray-700 hover:text-purple-600 transition-colors">Contact</a>
                  </div>
                </SheetContent>
              </Sheet>
            </div>
          </div>
        </div>
      </nav>

      {/* Cart Header */}
      <div className="pt-24 pb-8 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <h1 className="text-3xl font-bold text-gray-900">Shopping Cart</h1>
          <p className="text-gray-600 mt-2">
            {cartItems.length} {cartItems.length === 1 ? 'item' : 'items'} in your cart
          </p>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pb-16">
        {cartItems.length === 0 ? (
          <div className="text-center py-16">
            <div className="text-gray-400 mb-6">
              <ShoppingCart className="h-24 w-24 mx-auto" />
            </div>
            <h2 className="text-2xl font-semibold text-gray-900 mb-4">Your cart is empty</h2>
            <p className="text-gray-600 mb-8">Looks like you haven't added anything to your cart yet</p>
            <Button 
              className="bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700 text-white font-semibold px-8 py-3"
              onClick={() => window.location.href = '/shop'}
            >
              Continue Shopping
            </Button>
          </div>
        ) : (
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            {/* Cart Items */}
            <div className="lg:col-span-2 space-y-4">
              {cartItems.map((item) => (
                <Card key={item.id} className="overflow-hidden">
                  <CardContent className="p-6">
                    <div className="flex flex-col sm:flex-row gap-4">
                      <img 
                        src={item.image} 
                        alt={item.name}
                        className="w-full sm:w-24 h-24 sm:h-24 object-cover rounded-lg"
                      />
                      <div className="flex-1">
                        <div className="flex flex-col sm:flex-row sm:items-start sm:justify-between">
                          <div className="flex-1">
                            <h3 className="font-semibold text-lg text-gray-900 mb-1">{item.name}</h3>
                            <div className="flex flex-wrap gap-2 text-sm text-gray-600 mb-3">
                              <span>Size: {item.size}</span>
                              <span>•</span>
                              <span>Color: {item.color}</span>
                            </div>
                            <div className="flex items-center space-x-4">
                              <span className="text-lg font-bold text-gray-900">${item.price}</span>
                              <span className="text-sm text-gray-500 line-through">${item.originalPrice}</span>
                            </div>
                          </div>
                          <div className="flex items-center space-x-3 mt-3 sm:mt-0">
                            <div className="flex items-center border rounded-lg">
                              <Button
                                variant="ghost"
                                size="icon"
                                onClick={() => updateQuantity(item.id, item.quantity - 1)}
                                disabled={item.quantity <= 1}
                                className="h-8 w-8"
                              >
                                <Minus className="h-3 w-3" />
                              </Button>
                              <span className="w-8 text-center text-sm">{item.quantity}</span>
                              <Button
                                variant="ghost"
                                size="icon"
                                onClick={() => updateQuantity(item.id, item.quantity + 1)}
                                disabled={item.quantity >= item.stock}
                                className="h-8 w-8"
                              >
                                <Plus className="h-3 w-3" />
                              </Button>
                            </div>
                            <Button
                              variant="ghost"
                              size="icon"
                              onClick={() => removeItem(item.id)}
                              className="text-red-500 hover:text-red-600 h-8 w-8"
                            >
                              <Trash2 className="h-4 w-4" />
                            </Button>
                          </div>
                        </div>
                        <div className="mt-3 text-sm text-gray-600">
                          Subtotal: ${(item.price * item.quantity).toFixed(2)}
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}

              {/* Continue Shopping */}
              <div className="flex items-center justify-between pt-4">
                <Button 
                  variant="outline"
                  onClick={() => window.location.href = '/shop'}
                >
                  Continue Shopping
                </Button>
                <Button 
                  variant="ghost"
                  onClick={() => setCartItems([])}
                  className="text-red-500 hover:text-red-600"
                >
                  Clear Cart
                </Button>
              </div>
            </div>

            {/* Order Summary */}
            <div className="lg:col-span-1">
              <Card className="sticky top-24">
                <CardContent className="p-6">
                  <h2 className="text-xl font-semibold mb-6">Order Summary</h2>
                  
                  <div className="space-y-4 mb-6">
                    <div className="flex justify-between">
                      <span className="text-gray-600">Subtotal</span>
                      <span className="font-medium">${subtotal.toFixed(2)}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-600">Shipping</span>
                      <span className="font-medium">
                        {shipping === 0 ? 'FREE' : `$${shipping.toFixed(2)}`}
                      </span>
                    </div>
                    {discount > 0 && (
                      <div className="flex justify-between text-green-600">
                        <span>Discount</span>
                        <span className="font-medium">-${discount.toFixed(2)}</span>
                      </div>
                    )}
                    <Separator />
                    <div className="flex justify-between text-lg font-semibold">
                      <span>Total</span>
                      <span>${total.toFixed(2)}</span>
                    </div>
                  </div>

                  {/* Promo Code */}
                  <div className="mb-6">
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Promo Code
                    </label>
                    <div className="flex space-x-2">
                      <Input
                        type="text"
                        placeholder="Enter code"
                        value={promoCode}
                        onChange={(e) => setPromoCode(e.target.value)}
                        className="flex-1"
                      />
                      <Button 
                        variant="outline"
                        onClick={applyPromoCode}
                        disabled={!promoCode}
                      >
                        Apply
                      </Button>
                    </div>
                    <p className="text-xs text-gray-500 mt-2">Try: SAVE20 or SAVE10</p>
                  </div>

                  {/* Trust Badges */}
                  <div className="space-y-3 mb-6">
                    <div className="flex items-center space-x-3">
                      <Truck className="h-5 w-5 text-purple-600" />
                      <span className="text-sm text-gray-600">Free shipping on orders over $100</span>
                    </div>
                    <div className="flex items-center space-x-3">
                      <Shield className="h-5 w-5 text-purple-600" />
                      <span className="text-sm text-gray-600">Secure payment processing</span>
                    </div>
                  </div>

                  {/* Checkout Button */}
                  <Button 
                    className="w-full bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700 text-white font-semibold py-3 transition-all transform hover:scale-105"
                    onClick={() => alert('Proceeding to checkout...')}
                  >
                    Proceed to Checkout
                    <ArrowRight className="ml-2 h-5 w-5" />
                  </Button>

                  {/* Payment Methods */}
                  <div className="mt-6">
                    <p className="text-sm text-gray-600 mb-3">Accepted Payment Methods</p>
                    <div className="flex space-x-2">
                      <div className="w-12 h-8 bg-gray-200 rounded flex items-center justify-center text-xs font-medium">VISA</div>
                      <div className="w-12 h-8 bg-gray-200 rounded flex items-center justify-center text-xs font-medium">MC</div>
                      <div className="w-12 h-8 bg-gray-200 rounded flex items-center justify-center text-xs font-medium">AMEX</div>
                      <div className="w-12 h-8 bg-gray-200 rounded flex items-center justify-center text-xs font-medium">PP</div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>
        )}
      </div>
    </div>
  )
}