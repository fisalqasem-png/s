'use client'

import { useState, useEffect } from 'react'
import { ShoppingCart, Search, Menu, X, Heart, User, Filter, Grid, List, ChevronDown, Star, SlidersHorizontal } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Badge } from '@/components/ui/badge'
import { Card, CardContent } from '@/components/ui/card'
import { Sheet, SheetContent, SheetTrigger } from '@/components/ui/sheet'
import { Checkbox } from '@/components/ui/checkbox'
import { Slider } from '@/components/ui/slider'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'

export default function ShopPage() {
  const [isScrolled, setIsScrolled] = useState(false)
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false)
  const [cartItems, setCartItems] = useState(0)
  const [wishlistItems, setWishlistItems] = useState(0)
  const [viewMode, setViewMode] = useState<'grid' | 'list'>('grid')
  const [sortBy, setSortBy] = useState('featured')
  const [priceRange, setPriceRange] = useState([0, 500])
  const [selectedCategories, setSelectedCategories] = useState<string[]>([])
  const [selectedSizes, setSelectedSizes] = useState<string[]>([])
  const [selectedColors, setSelectedColors] = useState<string[]>([])
  const [searchQuery, setSearchQuery] = useState('')
  const [filterOpen, setFilterOpen] = useState(false)

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 20)
    }
    window.addEventListener('scroll', handleScroll)
    return () => window.removeEventListener('scroll', handleScroll)
  }, [])

  const allProducts = [
    {
      id: 1,
      name: "Premium Cotton T-Shirt",
      price: 49.99,
      originalPrice: 79.99,
      image: "https://images.unsplash.com/photo-1521572163474-6864f9cf17ab?w=500&h=600&fit=crop",
      category: "T-Shirts",
      sizes: ["XS", "S", "M", "L", "XL", "XXL"],
      colors: ["White", "Black", "Gray", "Navy"],
      badge: "New",
      rating: 4.8,
      reviews: 124,
      description: "Premium quality cotton t-shirt with perfect fit"
    },
    {
      id: 2,
      name: "Slim Fit Denim Jeans",
      price: 89.99,
      originalPrice: 129.99,
      image: "https://images.unsplash.com/photo-1542272604-787c3835535d?w=500&h=600&fit=crop",
      category: "Jeans",
      sizes: ["28", "30", "32", "34", "36"],
      colors: ["Blue", "Black", "Gray"],
      badge: "Sale",
      rating: 4.6,
      reviews: 89,
      description: "Modern slim fit denim with stretch comfort"
    },
    {
      id: 3,
      name: "Classic Leather Jacket",
      price: 199.99,
      originalPrice: 299.99,
      image: "https://images.unsplash.com/photo-1551488831-00ddcb6c6bd3?w=500&h=600&fit=crop",
      category: "Jackets",
      sizes: ["S", "M", "L", "XL"],
      colors: ["Black", "Brown"],
      badge: "Limited",
      rating: 4.9,
      reviews: 67,
      description: "Genuine leather jacket with timeless design"
    },
    {
      id: 4,
      name: "Casual Summer Dress",
      price: 69.99,
      originalPrice: 99.99,
      image: "https://images.unsplash.com/photo-1594633312681-425c7b97ccd1?w=500&h=600&fit=crop",
      category: "Dresses",
      sizes: ["XS", "S", "M", "L", "XL"],
      colors: ["Floral", "White", "Blue", "Pink"],
      badge: "Trending",
      rating: 4.7,
      reviews: 156,
      description: "Light and breezy summer dress"
    },
    {
      id: 5,
      name: "Premium Hoodie",
      price: 79.99,
      originalPrice: 119.99,
      image: "https://images.unsplash.com/photo-1556821840-3a63f95609a7?w=500&h=600&fit=crop",
      category: "Hoodies",
      sizes: ["S", "M", "L", "XL", "XXL"],
      colors: ["Gray", "Black", "Navy", "White"],
      badge: "Popular",
      rating: 4.5,
      reviews: 203,
      description: "Comfortable premium hoodie with modern fit"
    },
    {
      id: 6,
      name: "Tailored Blazer",
      price: 149.99,
      originalPrice: 199.99,
      image: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=500&h=600&fit=crop",
      category: "Blazers",
      sizes: ["S", "M", "L", "XL"],
      colors: ["Navy", "Gray", "Black"],
      badge: "New",
      rating: 4.8,
      reviews: 92,
      description: "Professional tailored blazer for any occasion"
    },
    {
      id: 7,
      name: "Casual Shorts",
      price: 39.99,
      originalPrice: 59.99,
      image: "https://images.unsplash.com/photo-1586790170083-2f9ceadc732d?w=500&h=600&fit=crop",
      category: "Shorts",
      sizes: ["28", "30", "32", "34", "36"],
      colors: ["Khaki", "Navy", "Black", "Gray"],
      badge: "Sale",
      rating: 4.4,
      reviews: 78,
      description: "Comfortable casual shorts for summer"
    },
    {
      id: 8,
      name: "Wool Sweater",
      price: 99.99,
      originalPrice: 149.99,
      image: "https://images.unsplash.com/photo-1434389677669-e08b4cac3105?w=500&h=600&fit=crop",
      category: "Sweaters",
      sizes: ["S", "M", "L", "XL"],
      colors: ["Cream", "Gray", "Navy", "Burgundy"],
      badge: "Winter",
      rating: 4.7,
      reviews: 145,
      description: "Premium wool sweater for cold weather"
    }
  ]

  const categories = ["T-Shirts", "Jeans", "Jackets", "Dresses", "Hoodies", "Blazers", "Shorts", "Sweaters"]
  const sizes = ["XS", "S", "M", "L", "XL", "XXL", "28", "30", "32", "34", "36"]
  const colors = ["White", "Black", "Gray", "Navy", "Blue", "Pink", "Red", "Brown", "Khaki", "Cream", "Burgundy", "Floral"]

  const filteredAndSortedProducts = allProducts
    .filter(product => {
      const matchesSearch = product.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
                           product.description.toLowerCase().includes(searchQuery.toLowerCase())
      const matchesCategory = selectedCategories.length === 0 || selectedCategories.includes(product.category)
      const matchesPrice = product.price >= priceRange[0] && product.price <= priceRange[1]
      const matchesSize = selectedSizes.length === 0 || product.sizes.some(size => selectedSizes.includes(size))
      const matchesColor = selectedColors.length === 0 || product.colors.some(color => selectedColors.includes(color))
      
      return matchesSearch && matchesCategory && matchesPrice && matchesSize && matchesColor
    })
    .sort((a, b) => {
      switch (sortBy) {
        case 'price-low':
          return a.price - b.price
        case 'price-high':
          return b.price - a.price
        case 'rating':
          return b.rating - a.rating
        case 'name':
          return a.name.localeCompare(b.name)
        default:
          return 0
      }
    })

  const addToCart = (productId: number) => {
    setCartItems(prev => prev + 1)
    const button = document.getElementById(`add-to-cart-${productId}`)
    if (button) {
      button.classList.add('scale-95')
      setTimeout(() => button.classList.remove('scale-95'), 200)
    }
  }

  const addToWishlist = (productId: number) => {
    setWishlistItems(prev => prev + 1)
  }

  const clearFilters = () => {
    setSelectedCategories([])
    setSelectedSizes([])
    setSelectedColors([])
    setPriceRange([0, 500])
    setSearchQuery('')
  }

  const activeFiltersCount = selectedCategories.length + selectedSizes.length + selectedColors.length + (searchQuery ? 1 : 0)

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Navigation */}
      <nav className={`fixed top-0 w-full z-50 transition-all duration-300 ${isScrolled ? 'bg-white shadow-lg' : 'bg-white/95 backdrop-blur-sm'}`}>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center">
              <h1 className="text-2xl font-bold bg-gradient-to-r from-purple-600 to-pink-600 bg-clip-text text-transparent">
                MIXARO
              </h1>
            </div>

            <div className="hidden md:flex items-center space-x-8">
              <a href="/" className="text-gray-700 hover:text-purple-600 transition-colors font-medium">Home</a>
              <a href="/shop" className="text-purple-600 font-medium">Shop</a>
              <a href="#" className="text-gray-700 hover:text-purple-600 transition-colors font-medium">Collections</a>
              <a href="#" className="text-gray-700 hover:text-purple-600 transition-colors font-medium">About</a>
              <a href="#" className="text-gray-700 hover:text-purple-600 transition-colors font-medium">Contact</a>
            </div>

            <div className="flex items-center space-x-4">
              <Button variant="ghost" size="icon" className="relative">
                <Search className="h-5 w-5" />
              </Button>
              <Button variant="ghost" size="icon" className="relative">
                <Heart className="h-5 w-5" />
                {wishlistItems > 0 && (
                  <Badge className="absolute -top-2 -right-2 h-5 w-5 rounded-full p-0 text-xs">
                    {wishlistItems}
                  </Badge>
                )}
              </Button>
              <Button variant="ghost" size="icon" className="relative">
                <ShoppingCart className="h-5 w-5" />
                {cartItems > 0 && (
                  <Badge className="absolute -top-2 -right-2 h-5 w-5 rounded-full p-0 text-xs">
                    {cartItems}
                  </Badge>
                )}
              </Button>
              <Button variant="ghost" size="icon">
                <User className="h-5 w-5" />
              </Button>

              <Sheet open={mobileMenuOpen} onOpenChange={setMobileMenuOpen}>
                <SheetTrigger asChild className="md:hidden">
                  <Button variant="ghost" size="icon">
                    <Menu className="h-5 w-5" />
                  </Button>
                </SheetTrigger>
                <SheetContent side="right" className="w-80">
                  <div className="flex flex-col space-y-4 mt-8">
                    <a href="/" className="text-lg font-medium text-gray-700 hover:text-purple-600 transition-colors">Home</a>
                    <a href="/shop" className="text-lg font-medium text-purple-600">Shop</a>
                    <a href="#" className="text-lg font-medium text-gray-700 hover:text-purple-600 transition-colors">Collections</a>
                    <a href="#" className="text-lg font-medium text-gray-700 hover:text-purple-600 transition-colors">About</a>
                    <a href="#" className="text-lg font-medium text-gray-700 hover:text-purple-600 transition-colors">Contact</a>
                  </div>
                </SheetContent>
              </Sheet>
            </div>
          </div>
        </div>
      </nav>

      {/* Shop Header */}
      <div className="pt-24 pb-8 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex flex-col md:flex-row md:items-center md:justify-between">
            <div>
              <h1 className="text-3xl font-bold text-gray-900">Shop</h1>
              <p className="text-gray-600 mt-2">Discover our premium collection</p>
            </div>
            <div className="mt-4 md:mt-0 flex items-center space-x-4">
              <div className="relative">
                <Input
                  type="text"
                  placeholder="Search products..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="pl-10 pr-4 py-2 w-64"
                />
                <Search className="absolute left-3 top-2.5 h-5 w-5 text-gray-400" />
              </div>
              <div className="flex items-center space-x-2">
                <Button
                  variant={viewMode === 'grid' ? 'default' : 'outline'}
                  size="icon"
                  onClick={() => setViewMode('grid')}
                >
                  <Grid className="h-4 w-4" />
                </Button>
                <Button
                  variant={viewMode === 'list' ? 'default' : 'outline'}
                  size="icon"
                  onClick={() => setViewMode('list')}
                >
                  <List className="h-4 w-4" />
                </Button>
              </div>
            </div>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pb-16">
        <div className="flex flex-col lg:flex-row gap-8">
          {/* Filters Sidebar */}
          <div className="lg:w-64">
            <div className="bg-white rounded-lg p-6 sticky top-24">
              <div className="flex items-center justify-between mb-6">
                <h2 className="text-lg font-semibold">Filters</h2>
                {activeFiltersCount > 0 && (
                  <Button variant="ghost" size="sm" onClick={clearFilters}>
                    Clear all
                  </Button>
                )}
              </div>

              {/* Mobile Filter Button */}
              <div className="lg:hidden mb-4">
                <Sheet open={filterOpen} onOpenChange={setFilterOpen}>
                  <SheetTrigger asChild>
                    <Button variant="outline" className="w-full">
                      <SlidersHorizontal className="h-4 w-4 mr-2" />
                      Filters ({activeFiltersCount})
                    </Button>
                  </SheetTrigger>
                  <SheetContent side="left" className="w-80 overflow-y-auto">
                    <div className="space-y-6 mt-8">
                      {/* Categories */}
                      <div>
                        <h3 className="font-medium mb-3">Categories</h3>
                        <div className="space-y-2">
                          {categories.map(category => (
                            <div key={category} className="flex items-center space-x-2">
                              <Checkbox
                                id={`mobile-category-${category}`}
                                checked={selectedCategories.includes(category)}
                                onCheckedChange={(checked) => {
                                  if (checked) {
                                    setSelectedCategories([...selectedCategories, category])
                                  } else {
                                    setSelectedCategories(selectedCategories.filter(c => c !== category))
                                  }
                                }}
                              />
                              <label htmlFor={`mobile-category-${category}`} className="text-sm">
                                {category}
                              </label>
                            </div>
                          ))}
                        </div>
                      </div>

                      {/* Price Range */}
                      <div>
                        <h3 className="font-medium mb-3">Price Range</h3>
                        <div className="space-y-3">
                          <Slider
                            value={priceRange}
                            onValueChange={setPriceRange}
                            max={500}
                            step={10}
                            className="w-full"
                          />
                          <div className="flex justify-between text-sm text-gray-600">
                            <span>${priceRange[0]}</span>
                            <span>${priceRange[1]}</span>
                          </div>
                        </div>
                      </div>

                      {/* Sizes */}
                      <div>
                        <h3 className="font-medium mb-3">Sizes</h3>
                        <div className="grid grid-cols-3 gap-2">
                          {sizes.map(size => (
                            <Button
                              key={size}
                              variant={selectedSizes.includes(size) ? 'default' : 'outline'}
                              size="sm"
                              onClick={() => {
                                if (selectedSizes.includes(size)) {
                                  setSelectedSizes(selectedSizes.filter(s => s !== size))
                                } else {
                                  setSelectedSizes([...selectedSizes, size])
                                }
                              }}
                            >
                              {size}
                            </Button>
                          ))}
                        </div>
                      </div>

                      {/* Colors */}
                      <div>
                        <h3 className="font-medium mb-3">Colors</h3>
                        <div className="space-y-2">
                          {colors.map(color => (
                            <div key={color} className="flex items-center space-x-2">
                              <Checkbox
                                id={`mobile-color-${color}`}
                                checked={selectedColors.includes(color)}
                                onCheckedChange={(checked) => {
                                  if (checked) {
                                    setSelectedColors([...selectedColors, color])
                                  } else {
                                    setSelectedColors(selectedColors.filter(c => c !== color))
                                  }
                                }}
                              />
                              <label htmlFor={`mobile-color-${color}`} className="text-sm">
                                {color}
                              </label>
                            </div>
                          ))}
                        </div>
                      </div>
                    </div>
                  </SheetContent>
                </Sheet>
              </div>

              {/* Desktop Filters */}
              <div className="hidden lg:block space-y-6">
                {/* Categories */}
                <div>
                  <h3 className="font-medium mb-3">Categories</h3>
                  <div className="space-y-2">
                    {categories.map(category => (
                      <div key={category} className="flex items-center space-x-2">
                        <Checkbox
                          id={`category-${category}`}
                          checked={selectedCategories.includes(category)}
                          onCheckedChange={(checked) => {
                            if (checked) {
                              setSelectedCategories([...selectedCategories, category])
                            } else {
                              setSelectedCategories(selectedCategories.filter(c => c !== category))
                            }
                          }}
                        />
                        <label htmlFor={`category-${category}`} className="text-sm">
                          {category}
                        </label>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Price Range */}
                <div>
                  <h3 className="font-medium mb-3">Price Range</h3>
                  <div className="space-y-3">
                    <Slider
                      value={priceRange}
                      onValueChange={setPriceRange}
                      max={500}
                      step={10}
                      className="w-full"
                    />
                    <div className="flex justify-between text-sm text-gray-600">
                      <span>${priceRange[0]}</span>
                      <span>${priceRange[1]}</span>
                    </div>
                  </div>
                </div>

                {/* Sizes */}
                <div>
                  <h3 className="font-medium mb-3">Sizes</h3>
                  <div className="grid grid-cols-3 gap-2">
                    {sizes.map(size => (
                      <Button
                        key={size}
                        variant={selectedSizes.includes(size) ? 'default' : 'outline'}
                        size="sm"
                        onClick={() => {
                          if (selectedSizes.includes(size)) {
                            setSelectedSizes(selectedSizes.filter(s => s !== size))
                          } else {
                            setSelectedSizes([...selectedSizes, size])
                          }
                        }}
                      >
                        {size}
                      </Button>
                    ))}
                  </div>
                </div>

                {/* Colors */}
                <div>
                  <h3 className="font-medium mb-3">Colors</h3>
                  <div className="space-y-2">
                    {colors.map(color => (
                      <div key={color} className="flex items-center space-x-2">
                        <Checkbox
                          id={`color-${color}`}
                          checked={selectedColors.includes(color)}
                          onCheckedChange={(checked) => {
                            if (checked) {
                              setSelectedColors([...selectedColors, color])
                            } else {
                              setSelectedColors(selectedColors.filter(c => c !== color))
                            }
                          }}
                        />
                        <label htmlFor={`color-${color}`} className="text-sm">
                          {color}
                        </label>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Products */}
          <div className="flex-1">
            {/* Sort and Results Count */}
            <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between mb-6">
              <p className="text-gray-600 mb-4 sm:mb-0">
                Showing {filteredAndSortedProducts.length} of {allProducts.length} products
              </p>
              <Select value={sortBy} onValueChange={setSortBy}>
                <SelectTrigger className="w-48">
                  <SelectValue placeholder="Sort by" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="featured">Featured</SelectItem>
                  <SelectItem value="price-low">Price: Low to High</SelectItem>
                  <SelectItem value="price-high">Price: High to Low</SelectItem>
                  <SelectItem value="rating">Highest Rated</SelectItem>
                  <SelectItem value="name">Name: A-Z</SelectItem>
                </SelectContent>
              </Select>
            </div>

            {/* Products Grid/List */}
            {viewMode === 'grid' ? (
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
                {filteredAndSortedProducts.map((product) => (
                  <Card key={product.id} className="group overflow-hidden hover:shadow-xl transition-all duration-300 transform hover:-translate-y-2">
                    <div className="relative">
                      <img 
                        src={product.image} 
                        alt={product.name}
                        className="w-full h-64 object-cover group-hover:scale-110 transition-transform duration-500"
                      />
                      <Badge className="absolute top-4 left-4 bg-red-500 hover:bg-red-600">
                        {product.badge}
                      </Badge>
                      <Button
                        variant="ghost"
                        size="icon"
                        className="absolute top-4 right-4 bg-white/80 hover:bg-white transition-all"
                        onClick={() => addToWishlist(product.id)}
                      >
                        <Heart className="h-4 w-4" />
                      </Button>
                    </div>
                    <CardContent className="p-6">
                      <div className="mb-2">
                        <span className="text-sm text-gray-500">{product.category}</span>
                      </div>
                      <h3 className="font-semibold text-lg text-gray-900 mb-2 group-hover:text-purple-600 transition-colors">
                        {product.name}
                      </h3>
                      <div className="flex items-center mb-3">
                        <div className="flex items-center">
                          {[...Array(5)].map((_, i) => (
                            <Star 
                              key={i} 
                              className={`h-4 w-4 ${i < Math.floor(product.rating) ? 'text-yellow-400 fill-current' : 'text-gray-300'}`} 
                            />
                          ))}
                        </div>
                        <span className="text-sm text-gray-500 ml-2">({product.reviews})</span>
                      </div>
                      <div className="flex items-center justify-between mb-4">
                        <div>
                          <span className="text-xl font-bold text-gray-900">${product.price}</span>
                          <span className="text-sm text-gray-500 line-through ml-2">${product.originalPrice}</span>
                        </div>
                      </div>
                      <Button 
                        id={`add-to-cart-${product.id}`}
                        className="w-full bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700 text-white font-semibold transition-all transform hover:scale-105"
                        onClick={() => addToCart(product.id)}
                      >
                        Add to Cart
                      </Button>
                    </CardContent>
                  </Card>
                ))}
              </div>
            ) : (
              <div className="space-y-6">
                {filteredAndSortedProducts.map((product) => (
                  <Card key={product.id} className="overflow-hidden hover:shadow-lg transition-all duration-300">
                    <div className="flex flex-col sm:flex-row">
                      <div className="relative sm:w-48 h-48 sm:h-auto">
                        <img 
                          src={product.image} 
                          alt={product.name}
                          className="w-full h-full object-cover"
                        />
                        <Badge className="absolute top-4 left-4 bg-red-500 hover:bg-red-600">
                          {product.badge}
                        </Badge>
                      </div>
                      <CardContent className="flex-1 p-6">
                        <div className="flex flex-col sm:flex-row sm:items-start sm:justify-between h-full">
                          <div className="flex-1">
                            <div className="mb-2">
                              <span className="text-sm text-gray-500">{product.category}</span>
                            </div>
                            <h3 className="font-semibold text-xl text-gray-900 mb-2 hover:text-purple-600 transition-colors">
                              {product.name}
                            </h3>
                            <p className="text-gray-600 mb-3">{product.description}</p>
                            <div className="flex items-center mb-4">
                              <div className="flex items-center">
                                {[...Array(5)].map((_, i) => (
                                  <Star 
                                    key={i} 
                                    className={`h-4 w-4 ${i < Math.floor(product.rating) ? 'text-yellow-400 fill-current' : 'text-gray-300'}`} 
                                  />
                                ))}
                              </div>
                              <span className="text-sm text-gray-500 ml-2">({product.reviews} reviews)</span>
                            </div>
                            <div className="flex flex-wrap gap-2 mb-4">
                              {product.sizes.slice(0, 4).map(size => (
                                <Badge key={size} variant="outline" className="text-xs">
                                  {size}
                                </Badge>
                              ))}
                              {product.sizes.length > 4 && (
                                <Badge variant="outline" className="text-xs">
                                  +{product.sizes.length - 4} more
                                </Badge>
                              )}
                            </div>
                          </div>
                          <div className="flex flex-col items-end justify-between sm:ml-6 mt-4 sm:mt-0">
                            <div className="text-right mb-4">
                              <div>
                                <span className="text-2xl font-bold text-gray-900">${product.price}</span>
                                <span className="text-sm text-gray-500 line-through block">${product.originalPrice}</span>
                              </div>
                            </div>
                            <div className="flex flex-col space-y-2">
                              <Button
                                variant="outline"
                                size="sm"
                                onClick={() => addToWishlist(product.id)}
                              >
                                <Heart className="h-4 w-4 mr-2" />
                                Wishlist
                              </Button>
                              <Button 
                                id={`add-to-cart-${product.id}`}
                                className="bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700 text-white"
                                onClick={() => addToCart(product.id)}
                              >
                                <ShoppingCart className="h-4 w-4 mr-2" />
                                Add to Cart
                              </Button>
                            </div>
                          </div>
                        </div>
                      </CardContent>
                    </div>
                  </Card>
                ))}
              </div>
            )}

            {filteredAndSortedProducts.length === 0 && (
              <div className="text-center py-12">
                <div className="text-gray-400 mb-4">
                  <Search className="h-16 w-16 mx-auto" />
                </div>
                <h3 className="text-xl font-semibold text-gray-900 mb-2">No products found</h3>
                <p className="text-gray-600 mb-4">Try adjusting your filters or search query</p>
                <Button onClick={clearFilters}>Clear all filters</Button>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  )
}